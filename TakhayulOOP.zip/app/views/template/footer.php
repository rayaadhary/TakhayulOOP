		<footer class="footer">
			<div class="copyright">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="copyright_content d-flex flex-md-row flex-column align-items-md-center align-items-start justify-content-start">
								<div class="cr">
									Copyright &copy;<script>
										document.write(new Date().getFullYear());
									</script> Sistem Aplikasi Takhayul
								</div>
								<div class="cr_right ml-md-auto">
									<div class="footer_social">
										<a class="cr_social_title" href="<?= BASEURL; ?>/home/tentang">Tentang</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		</div>

		<script src="<?= BASEURL; ?>/js/jquery-3.2.1.min.js"></script>
		<script src="<?= BASEURL; ?>/styles/bootstrap4/popper.js"></script>
		<script src="<?= BASEURL; ?>/styles/bootstrap4/bootstrap.min.js"></script>
		<script src="<?= BASEURL; ?>/plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
		<script src="<?= BASEURL; ?>/plugins/easing/easing.js"></script>
		<script src="<?= BASEURL; ?>/js/custom.js"></script>
		<script src="<?= BASEURL; ?>/plugins/parallax-js-master/parallax.min.js"></script>
		<script src="<?= BASEURL; ?>/plugins/progressbar/progressbar.min.js"></script>
		<!-- SweetAlert2 -->
		<script src="<?= BASEURL; ?>/js/sweetalert2.all.min.js"></script>
		<script src="<?= BASEURL; ?>/js/js-hapus.js"></script>
		<script src="<?= BASEURL; ?>/js/js-logout.js"></script>
		<script src="<?= BASEURL; ?>/js/contact.js"></script>

		<!-- Preloader -->
		<script>
			$(".preloader").fadeOut();
		</script>
		</body>

		</html>